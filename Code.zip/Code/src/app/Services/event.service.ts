import { Injectable } from '@angular/core';
import {Event} from 'src/app/Models/event'

@Injectable({
  providedIn: 'root'
})
export class EventService {
  private events: Event[];

  constructor() {
    this.events = [
      new Event(1,'Diwali','Festival of lights','User1','27/07/2020','27/07/2020','Active'),
      new Event(2,'Eid','Festival of peace','User2','27/07/2020','27/07/2020','Active'),
      new Event(3,'Cristmas','Festival of joy','User3','27/07/2020','27/07/2020','Active')
    
    ];

   }

   getEvents(){
    return this.events;
   }
}
