import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {AppComponent} from 'src/app/app.component';
import {EventDetailsComponent} from 'src/app/event-details/event-details.component';
import {EventlistComponent} from 'src/app/eventlist/eventlist.component'


const routes: Routes = [
  { path: 'home', component: EventlistComponent },
  {path:'EventDetails',component: EventDetailsComponent},
 { path: '', component: EventlistComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
