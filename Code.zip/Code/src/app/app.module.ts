import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EventDetailsComponent } from './event-details/event-details.component';
import { EventlistComponent } from './eventlist/eventlist.component';
import {EventService} from'./Services/event.service';

@NgModule({
  declarations: [
    AppComponent,
    EventDetailsComponent,
    EventlistComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [ EventService],
  bootstrap: [AppComponent]
})
export class AppModule { }
