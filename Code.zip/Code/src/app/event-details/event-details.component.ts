import { Component, OnInit,Input  } from '@angular/core';
import { Router } from '@angular/router';
import {Event} from 'src/app/Models/event'

@Component({
  selector: 'app-event-details',
  templateUrl: './event-details.component.html',
  styleUrls: ['./event-details.component.css']
})
export class EventDetailsComponent implements OnInit {

   public Event: Event;
  constructor(private router: Router) { }

  ngOnInit() {
    var data = window.history.state.data["item"];
    this.Event = new Event(data.id,data.eventName,data.description,data.createdBy,data.createdOn,data.modifiedOn,data.status);


  }

}
