export class Event {
    constructor(public id: number,
        public eventName: string,
        public description: string,
        public createdBy: string,
        public createdOn:string,
        public modifiedOn:string,
        public status:string){

    }
}
