import { Component, OnInit } from '@angular/core';
import {Event} from 'src/app/Models/event'
import { EventService } from 'src/app/Services/event.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-eventlist',
  templateUrl: './eventlist.component.html',
  styleUrls: ['./eventlist.component.css']
})
export class EventlistComponent implements OnInit {
  public events: Event[];
  constructor(private eventService: EventService,private router: Router) { }

  ngOnInit() {
    this.events = this.eventService.getEvents(); 
  }

  showEventDetails(item){
//this.router.navigate(['EventDetailsComponent']);
//this.router.navigateByUrl('/EventDetails',item);
this.router.navigate(['/EventDetails'], {state: {data: {item}}});
  }

}
